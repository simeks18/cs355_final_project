
#include <stdio.h>
#include "TPROTO.H"

VIDEO *crt;


void videoWrite (int row, int column, int length, char *str, int attr)
{

//Pointer to address of video memory
unsigned char *scrn;

//Access CPU register instead of memory if possible
//It will treat this as variable and will not allow & to be used
register int count; 
long offset;

//Holds the address of the video memory
scrn = (unsigned char *)crt->scrn;

//video memory = 1 byte / char & 1 byre / attribute (color)
//for this calc, there are 80 columns and 80 attributes so 160 bytes /row
//Starting pos
offset = (long)(row*160)+(column*2);

scrn = scrn + offset;

for(count = 0; count < length; count++){

//Writes the character pointed to by the string into the vram
//Is basically just writing to memory
*scrn++ = *str++;
*scrn++ = (unsigned)attr;

}
return;
}
