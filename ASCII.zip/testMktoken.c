//Note 11.17.2025 --> Used Gemini AI to write this
//Sadie Simek

#include "TPROTO.h"
#include <stdio.h>

void main(void) {
    int result;

    // Test creating a Red 'A'
    // 0x04 is Red, 0x41 is 'A'

    result = mkToken(0x41, 0x04);

    printf("Token created: 0x%x\n", result);
    
}
