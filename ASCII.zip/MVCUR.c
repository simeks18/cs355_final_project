//VT100 Programmer's Manual// 
// MVCUR.c

//mvCUR(row, column)

// returns nothing

#include <stdio.h>
#include "tproto.h"


//NOTE: ansi terminals mean these must be based on 1's and not 0
//Fix is to add +1 to the input values

//add the +1 inside the printf function
//If the row =1; 
//and column =1;
//Then it is immediately forgotten --> Must add +1 everytime for initalization


//Moving to POSIX standard 11.17.2025
void moveCursor(int row,int column)
{

//033 is octal from VT100
printf("\033[%d;%dH", row + 1, column + 1);

fflush(stdout);

}
