//MKATTR.c

//mkATTR(foreground, background, intensity, blink)

//Returns attr


#include "tproto.h"
#include <stdio.h>

int mkAttr(int foreground, int background, int intensity, int blink){

int attr;

attr = background*16;

 return (attr | foreground | intensity | blink);
}

