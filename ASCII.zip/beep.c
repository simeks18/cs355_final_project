//Beep.c
//Beeps the console speaker
//Returns nothing



#include <stdio.h>

#include "ascii.h"

void beep(){

printChar(aBEL);

}
