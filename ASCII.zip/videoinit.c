//basically ... pretend this array is the screen

#include <stdlib.h> // Needed to use 'malloc'
#include <stdio.h>
#include "tproto.h"

VIDEO *crt;

unsigned int safe_screen_memory[2000];

void videoInit(void) {

crt = (VIDEO *)malloc(sizeof(VIDEO));

crt->mode = 3;
crt->row_width = 80; // The screen is 80 characters wide
crt->page = 0;


crt->scrn = safe_screen_memory;

printf("System Initialized: Video Memory is ready at address %p\n", crt->scrn);
