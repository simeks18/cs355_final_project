//Demo progrogram for videochar, videoinit, mkToken, mkAttr

#include <stdio.h>
#include "TPROTO.H"
#include <string.h>

char test [] = "TEST VIDEOCHAR VIDEOINIT MKTOKEN MKATTR";
void main (void) {

int attr;
int token;
int index;
int row = 10;
int column = 10;	

//Row and column to display on (start on)

videoInit();

for (index = 0; index < strlen(test); index++){

//Blue background and white text constants from TSTRUCT.H

attr = mkAttr(WHITE, BLUE, OFF_INTENSITY, OFF_BLINK);

//make the token
token = mkToken(test[index], attr);

videoChar(row, column + index, token);
}
printf("Memory Written");

getchar();
}
