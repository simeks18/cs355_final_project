//DoFlag.c

//Demonstration Program for keyboard flag
//Inlcude Files

#include <stdio.h>
#include "TPROTO.H"
#include <stdlib.h>

int checkKeyboardFlag(void){

char rs[] = "Right Shift";
char ls[] = "Left Shift";
char ck[] = "Control Key";
char ak[] = "Alt Key";
char sl[] = "Scroll Lock";
char nl[] = "Number Lock";
char cl[] = "Caps Lock";
char ik[] = "Insert Key";

int flag; int value;
int exit_status = 0;

flag = checkKeyboardFlag();

//Bit 0 set with a right shift
value = flag % 2;
if(value) { exit_status = 1;}
else {
	value = flag & 1;
	if (value == 1)
		printf("%s-",rs);
	value = flag & 2;
        if (value == 2)
                printf("%s-",ls);
        value = flag & 4;
        if (value == 4)
                printf("%s-",ck);
        value = flag & 8;
        if (value == 8)
                printf("%s-",ak);
        value = flag & 16;
        if (value == 16)
                printf("%s-",sl);
        value = flag & 32;
        if (value == 32)
                printf("%s-",nl);
        value = flag & 64;
        if (value == 64)
                printf("%s-",cl);
        value = flag & 128;
        if (value == 128)
                printf("%s-",ik);
} printf("\r"); //clear line
return exit_status;
}
