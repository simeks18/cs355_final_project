
//void videoChar(int row , int column , int token);

// Sends the token directly to display RAM at row and column

//This call will only work after vidInit() has been called

#include <stdio.h>
#include "tproto.h"


extern VIDEO *crt; 

void videoChar(int row, int column, int token){
unsigned int *screen;

long offset;

// Set the pointer to the screen address
// The upper left corner 0,0

//CRT function holds the video configuration (like screen width and memory address)

screen = (unsigned int *)crt->screen;

//calculate the offset
//(row*width of screen)+ column

offset = (row * crt->row_width) + column;

//write token to the offset spot
screen[offset] = token;
}
