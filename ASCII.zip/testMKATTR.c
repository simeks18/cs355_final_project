#include <stdio.h>
#include "tproto.h"

int main() {

int foreground = 5;
int background = 1;
int intensity = 8;
int blink = 0; // no blinking

int result_attr = mkAttr(foreground, background, intensity, blink);

printf("Foreground value %i\n", foreground);
printf("Background value %i\n", background);
printf("Intensity value %i\n", intensity);
printf("Blink Value %i\n", blink);

return result_attr;
}
