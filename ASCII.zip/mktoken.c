//Token = mktoken(char ch, int attr)

//This file is used for direct video access
// int ch --> Character to be printed on the screen
// int token --> least significant byte holds the character to be printed
		// most significant byte holds the character attribute

// The goal is to receive the character to be printed and it's attribute and return the token.
// Token = word + it's styling
// Note: in VGA, the machine doesn't accept separate instructions for letter and color and they have to be passed together.. Not as relevant to us today.

# include "TPROTO.h"

int mkToken(int character, int attr){

int token;
token = attr <<8;
token |= character;
return token;
}

