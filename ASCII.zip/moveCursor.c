// 
// MVCUR.c

//mvCUR(row, column)

// returns nothing


#include <stdio.h>
#include "tproto.h"


//NOTE: ansi terminals mean these must be based on 1's and not 0
//Fix is to add +1 to each row and column 
void moveCursor(int row,int column)
{
row = 1;
column = 1;
printf("\033[%d;%dH", row, column);

fflush(stdout);

}
