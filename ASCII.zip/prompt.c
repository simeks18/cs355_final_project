#include <stdio.h>
#include "TPROTO.H"
#include <stdlib.h> //Include the standard library

int prompt (char *response, int length){

int key; int exitFlag; int row; int column;
int starting_place; int stopping_place;
int ret_val;

//Get the memory location of the row and the column
getCursor(&row, &column);

//current column is the start and the stopping point is
//equal to the start plus the length (in terms of positioning 
//on the screen

starting_place = column;
stopping_place = starting_place + length;

exitFlag = aFALSE;

do {
moveCursor(row, column);
key = getKey();

switch(key)
{
case ENTER:
ret_val = aTRUE;
exitFlag = aTRUE;
break;

case ESCAPE:
ret_val = aFALSE;
exitFlag = aTRUE;
break;

default:
key &=0x00ff;

//If the key is ASCII
if ((key>=0x20)&&(key<=0x7d)){

	if(column<stopping_place){
	moveCursor(row, column);
	printChar(key); //Pass the key to the screen by putting in the buffer
	*response++ = (char)key; //output buffer
	column++; //increment
}
else
	beep();
}
//IF THE KEY IS A BACKSPACE
if(key==aBS){
//IF THE KEY ISN'T YOUR STARTING SPACE
	if(column>starting_place){
//then go back one column
column--;
response--;

moveCursor(row,column);
printChar(' ');

*response = (char)aNUL;
}

else
//Audible sound at the beginning of the field entry
beep();
	}
	break;
	}
}while(!exit);
return(ret_val);
}

