#include <stdio.h>
#include "TPROTO.H"

void printChar (char ch){

//Linux wawy to print a character
putchar(ch);
fflush(stdout);

return;
}
