#include <stdio.h>
#include "TPROTO.H"
#include <stdlib.h>

int main (void){

int input = checkKeyboardFlag();
// Pass the value in as an int and as an hexadecimal value
printf("The raw keyboard flag value is: %d (0x%X)\n", input); //removed hex 11.18


return input;



}
