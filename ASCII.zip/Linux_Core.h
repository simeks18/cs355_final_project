#ifndef LINUX_CORE_H
#define LINUX_CORE_H

#define K_ESC 27
#define K_ARROW_UP 1000
#define K_ARROW_DOWN 1001
#define K_ARROW_LEFT 1002
#define K_ARROW_RIGHT 1003

// Function declarations (prototypes)
void enable_raw_mode();
void disable_raw_mode();
int read_key();

#endif
